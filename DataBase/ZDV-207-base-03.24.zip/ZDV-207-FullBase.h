//
//  FullBase.h
//  DataBase
//  Zakharov Daniil Vadimovich 207 gr.
//
//  Created by Daniil Zakharov on 25.03.2020.
//  Copyright © 2020 Daniil Zakharov. All rights reserved.
//

#ifndef FullBase_h
#define FullBase_h
#include <iostream>
#include "stdio.h"
#include <stdlib.h>
#include <string.h>
#include "ZDV-207-classbase.h"

class base {
private:
    record *records;
    int size;
    int *index;
public:
    base() {
        records = NULL;
        size = 0;
        index = 0;
    }
    
    int getsize() {
        return size;
    }
    
    record getindexrecord(int i) {
        int k = index[i];
        return records[k];
    }
    
    void renewindex(int sizew) {
        free(index);
        size = sizew;
        index = (int*)malloc((size)*sizeof(int));
        for (int i=0; i<size; i++) {
            index[i] = i ;
        }
    }
    
    void makebase(FILE *fout, int sizew);
    
    void printall(FILE *f = stdout) { // Распечатка
        for (int i=0; i<size; i++) {
            records[index[i]].printrecord(f);
        }
    }
    
    // Здесь и ниже ВЫБОРКИ
    
    // Из ТЕХНИЧЕСКИХ selectdate, selectsubject, selectlector, selectstudent, комментарии только в первой, остальные абсолютно аналогичны
    
    void selectdate(char * dat);
    
    void selectsubject(char * subj);
    
    void selectlector(char * lectname, char * lectsurname );
    
    void selectstudent(char * student);
    
    // ПОЛНАЯ ВЫБОРКА с учетом ЛЕКСИКОГРАФИЧЕСКИХ ПРАВИЛ
    
    void selectall (char * com );
    
    void addrecord(char * com);
    
    void offrecord(char * com);
};

#endif /* FullBase_h */
