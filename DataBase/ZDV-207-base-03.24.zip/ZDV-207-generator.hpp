//
//  ZDV-207-generator.hpp
//  DataBase
//
//  Created by Daniil Zakharov on 12.04.2020.
//  Copyright © 2020 Daniil Zakharov. All rights reserved.
//

#ifndef ZDV_207_generator_hpp
#define ZDV_207_generator_hpp

#include <stdio.h>

#endif /* ZDV_207_generator_hpp */
