//
//  classbase.h
//  DataBase
//  Zakharov Daniil Vadimovich 207 gr.
//
//  Created by Daniil Zakharov on 25.03.2020.
//  Copyright © 2020 Daniil Zakharov. All rights reserved.
//

#ifndef classbase_h
#define classbase_h
#include <iostream>
#include "stdio.h"
#include <stdlib.h>
#include <string.h>

class record {
private:
    char *namelect;
    char *surnlect;
    char *date;
    char *subject;
    char * students[10];
public:
    record() {
        namelect = NULL;
        surnlect = NULL;
        date = NULL;
        subject = NULL;
        //students = NULL;
        for (int i =0; i<10; i++) {
            students[i]= NULL;
        }
    }
    
    
    record& operator= (const record &rec) {
        namelect = strdup(rec.getnamelect());
        surnlect = strdup(rec.getsurnlect());
        date = strdup(rec.getdate());
        subject = strdup(rec.getsubject());
        for (int i=0; i<10; i++) {
            if (rec.getstudents(i)) {
                students[i] = strdup(rec.getstudents(i));
            }
        }
        return *this;
    }
    
    char * getnamelect() const {
        return namelect ;
    }
    char * getsurnlect() const {
        return surnlect;
    }
    char * getdate() const {
        return date;
    }
    char * getsubject() const {
        return subject;
    }
    char * getstudents(int i) const {
        return students[i];
    }
    
    void makerecord(char * w) {
        int num=0;      //индекс последнего слова
         char *q[18];   //слова в записи, их не больше 18
         int i;
         q[0] = strtok(w, " ");
         for(i=1;(i<19);i++) {
             q[i] = strtok(NULL, " ");
         }
         for (num=0; num<19; num++) {
             if (!q[num+1]) {
                 break;
             }
         }
        //Загрузка записи
        namelect = q[0];
        surnlect = q[1];
        subject = q[3];
        date = q[5];
        if (num > 6) {
            //students = (char**)malloc((num)*sizeof(char*));
            for (i=7; i<=num; i++) {
                students[i-7] = (char *)malloc(40);
                strcpy(students[i-7], q[i]);
            }
        }
    }
    
    
    
    void printrecord() {
        printf("%s %s %s %s ",namelect,surnlect,date,subject );
        printf("Студенты: ");
        for (int i=0; i<10; i++) {
            printf("%s ", students[i]);
            if (!students[i+1]) {
                break;
            }
        }
        printf("\n");
    }
};
 


#endif /* classbase_h */
